function temp() {
    let temporizadorBomba = setTimeout(() => {
        console.log("¡BOOM!");
    }, 500);

    if (Math.random() < 0.5) {
        console.log("Desactivada.");
        clearTimeout(temporizadorBomba); 
    }

    let tictac = 0;
    let reloj = setInterval(() => {
        console.log("tictac", tictac++);
        if (tictac == 10) {
            clearInterval(reloj);
            console.log("Detener.");
        }
    }, 200);
}

document.addEventListener("DOMContentLoaded", () => {
    temp();
});
