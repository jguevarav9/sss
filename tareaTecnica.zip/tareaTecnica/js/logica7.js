function act(){

    document.body.appendChild(document.createTextNode(
        "hola ".repeat(5000)));
        let barra = document.querySelector("#progreso");
        window.addEventListener("scroll", () => {
        let max = document.body.scrollHeight - innerHeight;
        barra.style.width = `${(pageYOffset / max) * 100}%`;
        });
    }
    document.addEventListener("DOMContentLoaded", () => {
    
        act();
    });