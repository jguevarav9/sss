function primerboton(){

    let boton1 = document.querySelector("#boton1")
    boton1.addEventListener("click", () => {
        console.log("boton presionado")
    });
}


function nodo() {
    let  boton2 = document.querySelector("#boton2");
    function unaVez(){

        console.log("Hecho.");
        boton2.removeEventListener("click", unaVez);
    }
    boton2.addEventListener("click", unaVez);
}

function objetoEvento(){

    let boton3 = document.querySelector("#boton3");
    boton3.addEventListener("mousedown", evento => {
    if (evento.button == 0) {
    console.log("Botón izquierdo");
    } else if (evento.button == 1) {
    console.log("Botón central");
    } else if (evento.button == 2) {
    console.log("Botón derecho");
    }
    });
}
function propagacion(){
    let parrafo = document.querySelector("#p");
let boton4 = document.querySelector("#boton4");

parrafo.addEventListener("mousedown", () => {
console.log("Manejador del párrafo.");
});
boton4.addEventListener("mousedown", evento => {
    console.log("Manejador del botón.");
   if (evento.button == 2) evento.stopPropagation();
});
}
document.addEventListener("DOMContentLoaded", () => {
    nodo();
    objetoEvento();
    primerboton();
    propagacion();
});
