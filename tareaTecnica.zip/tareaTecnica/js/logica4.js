function defecto(){

    let enlace = document.querySelector("a");
    enlace.addEventListener("click", evento => {
    console.log("Nope.");
    evento.preventDefault();
    252
    });
}

document.addEventListener("DOMContentLoaded", () => {
    
    defecto();
});