function puntero() {
    window.addEventListener("click", evento => {
        let punto = document.createElement("div");
        punto.className = "punto";
        punto.style.left = (evento.pageX - 4) + "px";
        punto.style.top = (evento.pageY - 4) + "px";
        document.body.appendChild(punto);
    });

    let barra = document.getElementById("barra");
    let ultimoX; // Rastrea la última posición de X del mouse

    barra.addEventListener("mousedown", evento => {
        if (evento.button === 0) {
            ultimoX = evento.clientX;
            window.addEventListener("mousemove", movido);
            evento.preventDefault(); 
        }
    });

    function movido(evento) {
        if (evento.buttons === 0) {
            window.removeEventListener("mousemove", movido);
        } else {
            let distancia = evento.clientX - ultimoX;
            let nuevaAnchura = Math.max(10, barra.offsetWidth + distancia);
            barra.style.width = nuevaAnchura + "px";
            ultimoX = evento.clientX;
        }
    }
}

document.addEventListener("DOMContentLoaded", () => {
    puntero();
});
