function manejoEvento(){
   window.addEventListener("click", () => {
        console.log("¿Tocaste?");
        })
       
}


document.addEventListener("DOMContentLoaded", () => {
    manejoEvento();
});
