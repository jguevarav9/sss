function propagacion(){
    let parrafo = document.querySelector("#p");
let boton4 = document.querySelector("#boton4");

parrafo.addEventListener("mousedown", () => {
console.log("Manejador del párrafo.");
});
boton4.addEventListener("mousedown", evento => {
    console.log("Manejador del botón.");
   if (evento.button == 2) evento.stopPropagation();
});
}

document.body.addEventListener("click", evento => {
if (evento.target.nodeName == "BUTTON") {
console.log("Presionado", evento.target.textContent);
}
});
document.addEventListener("DOMContentLoaded", () => {
    
    propagacion();
});