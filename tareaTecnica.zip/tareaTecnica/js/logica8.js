function foco() {
    let ayuda = document.querySelector("#ayuda");
    let campos = document.querySelectorAll("input");
    
    campos.forEach(campo => {
        campo.addEventListener("focus", evento => {
            let texto = evento.target.getAttribute("data-ayuda");
            ayuda.textContent = texto;
        });

        campo.addEventListener("blur", evento => {
            ayuda.textContent = "";
        });
    });
}

document.addEventListener("DOMContentLoaded", () => {
    foco();
});
