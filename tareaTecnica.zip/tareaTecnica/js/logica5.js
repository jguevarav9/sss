function teclado(){

    window.addEventListener("keydown", evento => {
        if (evento.key == "v") {
        document.body.style.background = "violet";
        }
        });
        window.addEventListener("keyup", evento => {
        if (evento.key == "v") {
        document.body.style.background = "";
        }
        })
        window.addEventListener("keydown", evento => {
            if (evento.key == "q") {
            document.body.style.background = "white";
            }
            });
            window.addEventListener("keyup", evento => {
            if (evento.key == "q") {
            document.body.style.background = "";
            }
            })
            window.addEventListener("keydown", evento => {
                if (evento.key == "s") {
                document.body.style.background = "blue";
                }
                });
                window.addEventListener("keyup", evento => {
                if (evento.key == "s") {
                document.body.style.background = "";
                }
                })
                window.addEventListener("keydown", evento => {
                    if (evento.key == "a") {
                    document.body.style.background = "pink";
                    }
                    });
                    window.addEventListener("keyup", evento => {
                    if (evento.key == "a") {
                    document.body.style.background = "";
                    }
                    })
        window.addEventListener("keydown", evento => {
            if (evento.key == " " && evento.ctrlKey) {
            console.log("¡Continuando!");
            }
            });
}
document.addEventListener("DOMContentLoaded", () => {
    
    teclado();
});
