function h(){
    let areaTexto = document.querySelector("textarea");
let tiempoEspera;
areaTexto.addEventListener("input", () => {
clearTimeout(tiempoEspera);
tiempoEspera = setTimeout(() => console.log("¡Escribió!"), 500);
});
let programado = null;
window.addEventListener("mousemove", evento => {
if (!programado) {
setTimeout(() => {
document.body.textContent =
`Mouse en ${programado.pageX}, ${programado.pageY}`;
programado = null;
}, 250);
}
programado = evento;
});

}
document.addEventListener("DOMContentLoaded", () => {
    
    h();
});